from lark import Lark, Token
from lark.tree import Tree
from termcolor import cprint

from mll.grammar_revision import get_rev_grammar
from mll.superMLL import superMLL
from mll.utils import scrivi, map, match, flatten, filter, group, clean_tok, \
    alphabet, \
    OR, visit, istok, apply, substitute_comp_SQ_W_SQ, isTree

import warnings

warnings.filterwarnings("ignore")


class MLL(superMLL):

    ###################################################################
    #                           START                                 #
    ###################################################################

    def __init__(self, program: str, env={}) -> None:
        superMLL.__init__(self,program, env)

    def start(self):
        self.create_available_imports()
        self.string = self.transpile(self.program)

    def transpile(self, program: str) -> str:

        print("                             DEBUG")
        print("###############################################################")

        parser = Lark(get_rev_grammar(), start='mll')

        self.before_tree = parser.parse(program)

        self.after_tree = Tree(self.before_tree.data, self.transform(self.before_tree.children))

        print("                             PROGRAM")
        print("###############################################################")
        s = scrivi(self.used_libraries) + "\n" + "def assign(x):\n\treturn x" + "\n\n" + scrivi(self.after_tree)

        # print("                             POSTCONDIZIONI")
        # cprint("macros: "+str(self.macros.keys()),"blue")
        # cprint("parmacs: " + str(self.parmacs.keys()), "blue")
        # print("###############################################################")

        return s

    ###################################################################
    #                        MAIN DISPATCHER                          #
    ###################################################################

    def translate_tree(self, t: Tree) -> Tree:
        if t.data == "mll":
            return Tree(t.data, self.translate_list(t.children))

        if t.data == "model":
            return self.translate_model(t)

        if t.data == "comp":
            return Tree(t.data, self.transform(t.children))

        if t.data == "comment":
            return None

        if t.data == "parmac":
            self.translate_parmac(t)

        if t.data == "macro":
            s = clean_tok(t.children[0])
            self.macros[s] = apply(t.children[2],
                                   lambda x: x,
                                   lambda x: Token("ID", "'" + s + "'") if s == clean_tok(x).value else x)

        if t.data == "e":
            return self.translate_e(t)

    def translate_token(self, t: Token) -> object:
        if clean_tok(t).value in self.macros.keys():
            t = self.solve_macro(t)
            if isTree(t):
                t = Tree(t.data, self.put_macros(t))
            if isinstance(t,list):
                t = self.put_macros(t)

        if clean_tok(t).value in self.parmacs.keys():
            t = apply(t,lambda x:x, self.solve_parmac)

        self.select_imported_libraries(t)

        return clean_tok(t) if istok(t) else t

    def translate_list(self, t: list):
        return filter(lambda x: x is not None, [self.transform(x) for x in t])

    def transform(self, t: object) -> object:
        if isinstance(t, Token):
            return self.translate_token(t)
        elif isinstance(t, Tree):
            return self.translate_tree(t)
        elif isinstance(t, type([])):
            return self.translate_list(t)
        else:
            raise Exception("Non esiste questo caso nella fun transform: ", type(t))

    ###################################################################
    #                       RULES DISPATCHER                          #
    ###################################################################

    def translate_e(self, t):
        # e ::= ID
        if match(t.children, [0], ["ID"]) and len(t.children) == 1:
            return Tree(t.data,[self.transform(t.children)])
        # e ::= ID e+
        if match(t.children, [0], ["ID"]) and len(t.children) > 1 and not match(t.children, [], ["PLUS"]):
            return Tree(t.data,
                        [t.children[0], Token("LP", "(")] +
                        map(self.transform, t.children[1:len(t.children)], "CO",",")+
                        [Token("RP", ")")])
        # e ::= LP e RP
        if match(t.children, [0, len(t.children)-1], ["LP", "RP"]):
            return Tree(t.data, [t.children[0]] +
                        [self.transform(t.children[1])] +
                        [t.children[2]])

        # e ::= 1234..
        if match(t.children, [0], ["NUMBER"]) and len(t.children) == 1:
            return t

        # e ::= 'ciao'
        if match(t.children, [0, 1, 2], ["SQ", "W", "SQ"]):
            return Token("W","'"+t.children[1]+"'")

        # e ::= e + e
        if match(t.children, [1], ["PLUS"]) and len(t.children) == 3:
            return Tree(t.data,[self.transform(t.children)])
        # e ::= e - e
        if match(t.children, [1], ["SUB"]) and len(t.children) == 3:
            return Tree(t.data,[self.transform(t.children)])
        # e ::= e * e
        if match(t.children, [1], ["MULT"]) and len(t.children) == 3:
            return Tree(t.data,[self.transform(t.children)])
        # e ::= e / e
        if match(t.children, [1], ["DIV"]) and len(t.children) == 3:
            return Tree(t.data,[self.transform(t.children)])

        if match(t.children, [0], ["WITH"]) and len(t.children) > 1:
            return Tree(t.data, map(self.transform, t.children[1:len(t.children)], "", ","))
        if match(t.children, [0], ["AT"]):
            return Tree(t.data, [t.children[1:]])

        if match(t.children, [0, 1], ["ID", "AR"]) and len(t.children) == 2:
            self.set_current_branch(t.children[0])
            return None
        if match(t.children, [0, 1], ["ID", "EQ"]) and len(t.children) > 2:
            return Tree(t.data,[self.transform(t.children)])

        return self.transform(t.children)

    def translate_model(self, t: Tree):

        if istok(t.children[2]) and t.children[2].type == "RR":
            self.regressors.append(t.children[1].value)
            t.children.pop(2)
        if istok(t.children[2]) and t.children[2].type == "CC":
            self.classifiers.append(t.children[1].value)
            t.children.pop(2)

        branches = list(group(t.children, "PI"))

        if len(branches) == 1:
            plus = lambda x: True if x.type == "PLUS" else False
            if visit(t, plus, OR):
                return self.traduce_sequential(t)
            else:
                return self.traduce_simple_model(t)
        else:
            return self.traduce_forks(t)

    ###################################################################
    #                           DAG MODEL                             #
    ###################################################################

    def traduce_forks(self, t: Tree):

        t.children[2:] = apply(t.children[2:],lambda x: [Token("ID","'"+x[1]+"'")] if match(x,[0,1,2],['SQ','W','SQ']) else x, lambda x: x)

        t.children[2:] = self.put_macros(t.children[2:])
        t.children[2:] = apply(t.children[2:], lambda x: x, self.solve_parmac)
        t = apply(t, lambda x: x, clean_tok)
        apply(t, lambda x: x, self.select_imported_libraries)
        # self.models[clean_tok(t.children[0]).value] = 0
        t.children[2:] = apply(t.children[2:], lambda x: x, self.substitute_model)
        t = apply(t, lambda x: x, self.solve_parmac)
        # self.ordered_models.append(clean_tok(t.children[0]).value)
        branches = t.children[2:]
        branches = list(group(branches, "PI"))

        a = []
        for branch in branches:
            a = a + self.traduce_branch(branch)

        branches = a

        b = self.current_bindings[len(self.current_bindings)-1]

        #  resetto tutto quando faccio il return
        self.current_bindings = []
        self.current_branch = 0

        return Tree(t.data,
                    [
                        Token("ID", "def "), Token("ID", t.children[0].value), Token("ID", "(x)"), Token("COLON", ":")
                    ] +
                    self.add_tab_top_level(branches) +
                    [
                        Token("ID", "return "), Token("ID", b), Token("WS", "\n\n")
                    ]
                    )

    def traduce_branch(self, branch: list) -> list:
        # branch contiene una e perciò la facciamo uscire
        a = []
        for i in branch:
            self.current_branch += 1
            self.current_bindings.append(alphabet[self.current_branch - 1])
            a.append(self.traduce_layers(branch, "first"))
        return a

    # All' inizio t è una lista ma tutte le successive call sono su trees
    def traduce_layers(self, t: list, opt=""):
        # (layer + ( layer + layer ))

        if isinstance(t, list):
            t = t[0]

        if match(t.children, [1], ["PLUS"]) and len(t.children) == 3:
            if opt == "first":
                return Tree(t.data, [Tree(t.children[0].data, [self.traduce_layers(t.children[0], "first")]),
                                     Tree(t.children[2].data, [self.traduce_layers(t.children[2])])])
            else:
                return Tree(t.data, [Tree(t.children[0].data, [self.traduce_layers(t.children[0])]),
                                     Tree(t.children[0].data, [self.traduce_layers(t.children[2])])])

        if match(t.children, [0], ["ID"]) and len(t.children) > 1 and not match(t.children, [], ["PLUS"]):
            if clean_tok(t.children[0]).value == "assign":
                return Tree(t.data, [Token("ID", alphabet[self.current_branch - 1]), Token("EQ", "="), t.children[0],
                                     Token("LP", "(")] + map(lambda x: x, t.children[1:], "CO", ",") + [
                                Token("RP", ")"),
                                Token("WS", "\n\t")])

            if opt == "first":
                return Tree(t.data, [Token("ID", alphabet[self.current_branch - 1]), Token("EQ", "="), t.children[0],
                                     Token("LP", "(")] + map(lambda x: x, t.children[1:], "CO", ",") + [
                                Token("RP", ")"), Token("LP", "("), Token("ID", "x"), Token("RP", ")"),
                                Token("WS", "\n\t")])
            else:
                return Tree(t.data,
                            [
                                Token("ID", alphabet[self.current_branch - 1]),
                                Token("EQ", "="), t.children[0],
                                Token("LP", "(")] +
                            map(lambda x: x, t.children[1:], "CO", ",") +
                            [
                                Token("RP", ")"),
                                Token("LP", "("),
                                Token("ID", alphabet[self.current_branch - 1]),
                                Token("RP", ")"),
                                Token("WS", "\n\t")
                            ])

        if match(t.children, [0], ["ID"]) and match(t.children, [1], ["AR"]) and len(t.children) == 2:
            # preparati per dare 2 bindings
            pass

        if match(t.children, [0], ["ID"]) and match(t.children, [1], ["AR"]) and len(t.children) == 4:
            # concatena 2 concatenazioni che sono state bindate
            pass

        if match(t.children, [0], ["ID"]) and len(t.children) == 1:
            a = str(self.current_bindings[:len(self.current_bindings) - 1]).replace("'", "").replace("x,", "")
            self.current_bindings = ["x"]

            return Tree(t.data,
                        [
                            Token("ID", "x"),
                            Token("EQ", "="), t.children[0],
                            Token("LP", "("),
                            Token("RP", ")"),
                            Token("LP", "("),
                            Token("ID", a),
                            Token("RP", ")"),
                            Token("WS", "\n\t")
                        ])

        return Tree(t.data, [self.traduce_layers(t.children, opt)])

    ###################################################################
    #                      SEQUENTIAL MODEL                           #
    ###################################################################

    def traduce_sequential(self, t: Tree):

        t.children[2:] = self.put_macros(t.children[2:])
        t = apply(t, lambda x: x, clean_tok)
        apply(t, lambda x: x, self.select_imported_libraries)
        self.models[clean_tok(t.children[0]).value] = 0
        self.select_imported_libraries(Token("ID", "Sequential"))
        t = apply(t, lambda x: x, self.solve_parmac)

        return Tree(t.data,
                    [Token("ID", "models"), Token("LSP", "["), Token("SQ", "'"), clean_tok(t.children[0]),
                     Token("SQ", "'"), Token("LSP", "]"), Token("EQ", "="), Token("ID", "Sequential"), Token("LP", "("),
                     Token("LSP", "[")] +
                    apply(map(self.transform, t.children[2:], "CO", ","), lambda x: x,
                          lambda x: Token("CO", ",") if x.type == "PLUS" else x) +
                    [Token("RSP", "]"), Token("RP", ")"), Token("WS", "\n\n")])

    ###################################################################
    #                        SIMPLE MODEL                             #
    ###################################################################

    def traduce_simple_model(self, t: Tree):

        t.children[2:] = self.put_macros(t.children[2:])
        t = apply(t, lambda x: x, clean_tok)
        apply(t, lambda x: x, self.select_imported_libraries)
        self.models[clean_tok(t.children[0]).value] = 0
        t.children[2:] = apply(t.children[2:], lambda x: x, self.substitute_model)
        t = apply(t, lambda x: x, self.solve_parmac)
        self.ordered_models.append(clean_tok(t.children[0]).value)

        if len(t.children[2:][0].children) == 1:
            return Tree(t.data,
                        [Token("ID", "models"), Token("LSP", "["), Token("SQ", "'"), clean_tok(t.children[0]),
                         Token("SQ", "'"), Token("LSP", "]"), Token("EQ", "=")]
                        +
                        map(self.transform, t.children[2:], "CO", ",")
                        + [Token("LP", "("), Token("RP", ")"), Token("WS", "\n")])
        return Tree(t.data,
                    [Token("ID", "models"), Token("LSP", "["), Token("SQ", "'"), clean_tok(t.children[0]),
                     Token("SQ", "'"), Token("LSP", "]"), Token("EQ", "=")]
                    +
                    map(self.transform, t.children[2:], "CO", ",")
                    + [Token("WS", "\n\n")])
