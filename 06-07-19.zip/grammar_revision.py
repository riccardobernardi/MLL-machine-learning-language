new_grammar = """

//////////////PARSER RULES

mll : ( model | macro | parmac | comment )+

model : ID COLON [_rc] [PI] e (_nn)*

_rc.2 : RR | CC

_nn : ( PI e )
    | ( PI ID AR )

comment : HASH (W | NUM | CO | " ")* WSP

parmac : ID IS ID (OR ID)*

macro : ID EQC e (_nn)*

e   : ID
    | LP e RP // applicazione di funzione
    | NUMBER
    | SQ W SQ
    | e PLUS e
    | e MULT e
    | e SUB e
    | e DIV e
    | AT e
    | AT ID LP RP
    | ID (e | comp)+
            
comp: ID EQ LSP (e 
            | e COLON
            | e CO )+ RSP 
    | ID EQ LP (e 
            | e CO)+ RP 
    | ID EQ BL (e 
            | e COLON)+ BR 
    | ID EQ SQ W SQ
    | ID EQ NUMBER
    | ID EQ ID
    | LP ( e CO )+ e RP 
    
// | e LSP e RSP
    
// | e DO e+
    
// ID ( e | ID EQ e | ID EQ LSP (e | e COLON)+ RSP | ID EQ BL (e | e COLON)+ BR)+
    
// BL (e | e COLON)  BR #
// | LSP (e | e COLON) RSP #
// | e CO #
// | WITH e #
// | AR #
// | ID EQ [ID [DO ID]+] #
// | PI e #
// | OR e #
    
//////////////LEXER TERMINALS

MULT : "*" WS

OR : "or" WS

AT : "@"

SUB : "-" WS

DIV : "/" WS

AR : "->" WS

EX : "!" WS

HASH : WS "#" [" "]+

RR : ("REGRESSOR" | "regressor") WS

CC : ("CLASSIFIER" | "classifier") WS

IS : "is" WS

EQC : ":=" WS

PLUS : "+" WS

WITH  : "with" WS

PI : "|" WS

CO : "," WS

DO  : "." WS

SQ : "'" WS

EQ : "=" WS

BR : "}" WS

BL  : "{" WS

LP : "(" WS

RP : ")" WS

LSP : "[" WS

RSP : "]" WS

ID : WS W [INTEGER | W]+ WS

NWID : W [INTEGER | W]+

WID : W [INTEGER | W]+

COLON   : ":" WS

W   : ("a".."z" | "A".."Z" | "_" )+

WS : (" " | "\\n" | "\\t" | "\\r")*

WSP : (" " | "\\n" | "\\t" | "\\r")+

WSS : (" " | "\\n" | "\\t" | "\\r")

INTEGER  :   ("0".."9")+

DECIMAL  :   INTEGER ["." INTEGER]

NUMBER   :   NUM WS

NUM : (DECIMAL | INTEGER)

"""

def get_rev_grammar():
    return new_grammar
