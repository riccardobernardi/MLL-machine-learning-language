from keras import layers, backend
from lark import Tree, Token
from termcolor import cprint


def stampa(t: object) -> None:
    # stampa un albero a schermo, non scrive su stringhe

    if isinstance(t, Token):
        print(t.value, end='')
    elif isinstance(t, Tree):
        stampa(t.children)
    elif isinstance(t, type([])):
        for i in t:
            stampa(i)
    else:
        raise Exception("Non esiste questo caso nella fun stampa")


def scrivi(t: object) -> str:
    # ritorna una stringa con l' albero dentro
    if isinstance(t, Token):
        return t
    elif isinstance(t, Tree):
        return scrivi(t.children)
    elif isinstance(t, type([])):
        s = ""
        for i in t:
            s += scrivi(i)
        return s
    elif isinstance(t, type("")):
        return t
    else:
        cprint(type(t),"blue")
        raise Exception("Non esiste questo caso nella fun scrivi")


def istok(i: object) -> bool:
    if isinstance(i, Token):
        return True
    else:
        return False


def clean_tok(tok: Token) -> Token:
    # if tok.type=="W":
    #     return tok
    # if tok.type == "WSP":
    #     return Token(tok.type, tok.value.replace("\t", ""))
    return Token(tok.type, tok.value.replace(" ", "").replace("\t", "").replace("\n", ""))


from keras import models


def get_keras_layers() -> dict:
    keras_layers = {}

    keras_layers["models"] = set()
    for k in models.__dict__.keys():
        if "__" not in k and k != "K":
            keras_layers["models"].add(k)

    keras_layers["layers"] = set()
    for k in layers.__dict__.keys():
        if "__" not in k and k != "K":
            keras_layers["layers"].add(k)

    keras_layers["backend"] = set()
    for k in backend.__dict__.keys():
        if "__" not in k and k != "K":
            keras_layers["backend"].add(k)

    return keras_layers


from sklearn import linear_model
from sklearn import cluster
from sklearn import ensemble
from sklearn import neighbors
from sklearn import svm
from sklearn import tree


def get_sklearn_models() -> dict:
    keras_layers = {}

    # keras_layers = {n*set()}

    keras_layers["linear_model"] = set()
    for k in linear_model.__dict__.keys():
        if "__" not in k and k != "K":
            keras_layers["linear_model"].add(k)

    keras_layers["cluster"] = set()
    for k in cluster.__dict__.keys():
        if "__" not in k and k != "K":
            keras_layers["cluster"].add(k)

    keras_layers["ensemble"] = set()
    for k in ensemble.__dict__.keys():
        if "__" not in k and k != "K":
            keras_layers["ensemble"].add(k)

    # print("EUREKAAAAAAA","RandomForestClassifier" in keras_layers["ensemble"])

    keras_layers["neighbors"] = set()
    for k in neighbors.__dict__.keys():
        if "__" not in k and k != "K":
            keras_layers["neighbors"].add(k)

    keras_layers["svm"] = set()
    for k in svm.__dict__.keys():
        if "__" not in k and k != "K":
            keras_layers["svm"].add(k)

    keras_layers["tree"] = set()
    for k in tree.__dict__.keys():
        if "__" not in k and k != "K":
            keras_layers["tree"].add(k)

    return keras_layers


from mlxtend import classifier


def get_mlxtend_models() -> dict:
    keras_layers = {}

    # keras_layers = {n*set()}

    keras_layers["classifier"] = set()
    for k in classifier.__dict__.keys():
        if "__" not in k and k != "K":
            keras_layers["classifier"].add(k)

    return keras_layers


def isTree(t: object) -> bool:
    if isinstance(t, Tree):
        return True
    return False


def presentation():
    print()
    print("######################################################################")
    print("#                            STARTING MLL                            #")
    print("######################################################################")
    print("# 1. model = MLL('PROGRAM.MLL')                                      #")
    print("# 2. model.start() -> to pass from MLL to python                     #")
    print("# 3. model.get_string() -> to get python code of your program        #")
    print("# 4. model.execute() -> to run python code of your program           #")
    print("# 5. clf = model.last_model() -> to get last model of your program   #")
    print("# 6. MLL() -> to get this window                                     #")
    print("#                                                                    #")
    print("#                                    student: Bernardi Riccardo      #")
    print("#                                    supervisor: Lucchese Claudio    #")
    print("#                                    co-supervisor: Spanò Alvise     #")
    print("######################################################################")


def map(f: type(map), arr: [], type_between: type("") = "", between: type("") = "", opt: str = "") -> []:
    a = []
    for i in arr:
        if opt != "":
            a.append(f(i, opt))
        else:
            a.append(f(i))
        if type_between != "":
            a.append(Token(type_between, between))

    if type_between != "":
        a = a[0:len(a) - 1]

    return a


def AND(a, b):
    return a and b


def reduce(f: type(map), arr: []):
    if len(arr) == 1:
        return arr[0]
    else:
        n = f(arr[0], arr[1])
        arr.pop(0)
        arr.pop(0)
        arr.insert(0, n)
        return reduce(f, arr)


def OR(a, b):
    return a or b


def match(children, indexes, tok_types):

    # print(len(indexes))

    try:
        if len(indexes)>0:
            true = [children[indexes[i]].type == tok_types[i] for i in range(0, len(indexes))]
        else:
            true = []
            for i in range(0, len(children)):
                if isinstance(children[i],Token):
                    true.append(children[i].type == tok_types[0])
    except:
        # cprint("esco sull except della match","green")
        return False

    return reduce(AND, true) if len(indexes)>0 else reduce(OR,true)


def split(arr: [], split_token: type("")) -> []:
    a = []
    # arr = arr[1:] #tolgo la prima pipe per comodità
    last_split = 0

    for i in range(0, len(arr)):
        if isinstance(arr[i],Token) and arr[i].type == split_token and arr[i] is not None:
            b = arr[last_split:i]
            a.append(b)
            last_split = i + 1

    return a


def flatten(ndim):
    a = []

    for i in ndim:
        if type(i) == list:
            b = flatten(i)
            a = a + b
        else:
            a = a + [i]

    return a


def filter(f, arr: []) -> []:
    a = []

    for i in arr:
        if f(i):
            a.append(i)

    return a


def group(seq: [], sep: str):
    g = []
    for el in seq:
        if type(el) == Token and el.type == sep:
            yield g
            g = []
        if type(el) == Token and el.type == sep:
            continue
        else:
            g = g + [el]
    yield g


put_tabs = lambda x: Token(x.type, "\t" + x.value) if type(x) == Token else map(put_tabs, x.children)

cut_tabs = lambda x: clean_tok(x) if type(x) == Token else map(cut_tabs, x.children)


def MAX(a: int, b: int):
    return a if a > b else b


def tree_depth(t) -> int:
    if type(t) == Tree:
        # print("from TRee of treedepth",t)
        a: int = tree_depth(t.children)
        # print("from tredepth what come from depthiness",a)
        return 1 + a
    if type(t) == Token:
        return 0
    if isinstance(t, list):
        # print(reduce(MAX, map(tree_depth,t)))
        return reduce(MAX, map(tree_depth, t))

    raise Exception("Errorfffffffff")


alphabet = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'z']


def list_types_list(l:[])->[]:
    return [ x.data if type(x)==Tree else x.type for x in l]


def escape(t:Token, m: Tree) -> Tree:

    for i in range(0,len(m.children)):
        if isinstance(m.children[i], Token) and clean_tok(t) == clean_tok(m.children[i]):
            m.children.pop(i)
            m.children.insert(i,Token("ID","'"+t.value+"'"))

    return m


def descend_left(t: Tree):
    if isinstance(t, Token):
        return t
    if isinstance(t.children[0], Token):
        return t.children[0]
    else:
        return descend_left(t.children[0])


def delete_descending_left(t: Tree):
    if isinstance(t.children[0], Token):
        t.children[0] = None
    else:
        delete_descending_left(t.children[0])


def visit(t: object, match, red):
    if isinstance(t, Token):
        return match(t)
    elif isinstance(t, Tree):
        return visit(t.children,match,red)
    elif isinstance(t, type([])):
        a = []
        for i in t:
            b = visit(i,match,red)
            a.append(b)
        return reduce(red,a)
    else:
        cprint(type(t),"blue")
        raise Exception("Non esiste questo caso nella fun scrivi")


def apply(t: object, flist, ftok):
    if isinstance(t, Token):
        return ftok(t)
    elif isinstance(t, Tree):
        return Tree(t.data,apply(t.children, flist, ftok))
    elif isinstance(t, type([])):
        a = []
        for i in t:
            b = apply(i, flist, ftok)
            a.append(b)
        return flist(a)
    else:
        cprint(type(t),"blue")
        raise Exception("Non esiste questo caso nella fun scrivi")


def sub_comp_sq_w_sq(t: list):
    if match(t, [0, 1, 2, 3, 4], ["ID", "EQ", "SQ", "W", "SQ"]) and len(t) == 5:
        m = [Token("ID", clean_tok(t[0]).value), Token("EQ","="), Token("ID","'" + clean_tok(t[3]).value + "'")]
        return m
    else:
        return t


def substitute_comp_SQ_W_SQ(t):
    return apply(t, sub_comp_sq_w_sq, lambda x: x)
