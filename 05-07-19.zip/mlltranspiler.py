from lark import Lark, Token
from lark.tree import Tree
from termcolor import cprint

from mll.Macro import Macro
from mll.Parmac import Parmac
from mll.grammar_revision import get_rev_grammar
from mll.superMLL import superMLL
from mll.utils import scrivi, map, match, flatten, filter, group, clean_tok, \
    alphabet, \
    OR, visit, istok, apply, substitute_comp_SQ_W_SQ

import warnings

warnings.filterwarnings("ignore")


class MLL(superMLL):

    ###################################################################
    #                           START                                 #
    ###################################################################

    def __init__(self, program: str, env={}) -> None:
        superMLL.__init__(self,program, env)

    def start(self):
        self.create_available_imports()
        self.string = self.transpile(self.program)

    def transpile(self, program: str) -> str:

        print("                             DEBUG")
        print("###############################################################")

        parser = Lark(get_rev_grammar(), start='mll')

        self.before_tree = parser.parse(program)

        self.after_tree = Tree(self.before_tree.data, self.transform(self.before_tree.children))

        print("                             PROGRAM")
        print("###############################################################")
        s = scrivi(self.used_libraries) + "\n" + "def assign(x):\n\treturn x" + "\n\n" + scrivi(self.after_tree)

        # print("                             POSTCONDIZIONI")
        # cprint("macros: "+str(self.macros.keys()),"blue")
        # cprint("parmacs: " + str(self.parmacs.keys()), "blue")
        # print("###############################################################")

        return s

    ###################################################################
    #                        MAIN DISPATCHER                          #
    ###################################################################

    def translate_tree(self, t: Tree) -> Tree:
        if t.data == "mll":
            return Tree(t.data, self.translate_list(t.children))

        if t.data == "model":
            return self.translate_model(t)

        if t.data == "comp":
            return t

        if t.data == "comment":
            return None

        if t.data == "parmac":
            self.parmacs = Parmac(self.parmacs).add(t).getAll()

        if t.data == "macro":
            self.macros = Macro(self.macros).add(t).getAll()

    def translate_token(self, t: Token) -> object:
        if clean_tok(t).value in self.macros.keys():
            t = self.put_macros(t)
            return t

        if clean_tok(t).value in self.parmacs.keys():
            return self.solve_parmac(t)

        self.select_imported_libraries(t)

        return clean_tok(t)

    def translate_list(self, t: list):
        return filter(lambda x: x is not None, [self.transform(x) for x in t])

    def transform(self, t: object) -> object:
        if isinstance(t, Token):
            return self.translate_token(t)
        elif isinstance(t, Tree):
            return self.translate_tree(t)
        elif isinstance(t, type([])):
            return self.translate_list(t)
        else:
            raise Exception("Non esiste questo caso nella fun transform: ", type(t))

    ###################################################################
    #                       RULES DISPATCHER                          #
    ###################################################################

    def translate_model(self, t: Tree):

        if istok(t.children[2]) and t.children[2].type == "RR":
            self.regressors.append(t.children[1].value)
            t.children.pop(2)
        if istok(t.children[2]) and t.children[2].type == "CC":
            self.classifiers.append(t.children[1].value)
            t.children.pop(2)

        branches = list(group(t.children, "PI"))

        if len(branches) == 1:
            plus = lambda x: True if x.type == "PLUS" else False
            if visit(t, plus, OR):
                return self.traduce_sequential(t)
            else:
                return self.traduce_simple_model(t)
        else:
            return self.traduce_forks(t)
