from lark import Tree, Token

from mll.utils import clean_tok, apply, group, alphabet, match, map


class ForkedModel:

    def __init__(self):

    ###################################################################
    #                           DAG MODEL                             #
    ###################################################################

    def translate_e(self, t):
        # e ::= ID
        if match(t.children, [0], ["ID"]) and len(t.children) == 1:
            return Tree(t.data,[self.transform(t.children)])
        # e ::= ID e+
        if match(t.children, [0], ["ID"]) and len(t.children) > 1 and not match(t.children, [], ["PLUS"]):
            return Tree(t.data,
                        [t.children[0], Token("LP", "(")] +
                        map(self.transform, t.children[1:len(t.children)], "CO",",")+
                        [Token("RP", ")")])
        # e ::= LP e RP
        if match(t.children, [0, len(t.children)-1], ["LP", "RP"]):
            return Tree(t.data, [t.children[0]] +
                        [self.transform(t.children[1])] +
                        [t.children[2]])

        # e ::= 1234..
        if match(t.children, [0], ["NUMBER"]) and len(t.children) == 1:
            return t

        # e ::= 'ciao'
        if match(t.children, [0, 1, 2], ["SQ", "W", "SQ"]):
            return t

        # e ::= e + e
        if match(t.children, [1], ["PLUS"]) and len(t.children) == 3:
            return Tree(t.data,[self.transform(t.children)])
        # e ::= e - e
        if match(t.children, [1], ["SUB"]) and len(t.children) == 3:
            return Tree(t.data,[self.transform(t.children)])
        # e ::= e * e
        if match(t.children, [1], ["MULT"]) and len(t.children) == 3:
            return Tree(t.data,[self.transform(t.children)])
        # e ::= e / e
        if match(t.children, [1], ["DIV"]) and len(t.children) == 3:
            return Tree(t.data,[self.transform(t.children)])

        if match(t.children, [0], ["WITH"]) and len(t.children) > 1:
            return Tree(t.data, map(self.transform, t.children[1:len(t.children)], "", ","))
        if match(t.children, [0], ["AT"]):
            return Tree(t.data, [t.children[1:]])

        if match(t.children, [0, 1], ["ID", "AR"]) and len(t.children) == 2:
            self.set_current_branch(t.children[0])
            return None
        if match(t.children, [0, 1], ["ID", "EQ"]) and len(t.children) > 2:
            return Tree(t.data,[self.transform(t.children)])

        return self.transform(t.children)

    def start(self,t: Tree):
        return traduce_forks(t)

    def traduce_forks(self, t: Tree):

        t.children[2:] = self.put_macros(t.children[2:])
        t = apply(t, lambda x: x, clean_tok)
        apply(t, lambda x: x, self.select_imported_libraries)
        # self.models[clean_tok(t.children[0]).value] = 0
        t.children[2:] = apply(t.children[2:], lambda x: x, self.substitute_model)
        t = apply(t, lambda x: x, self.solve_parmac)
        # self.ordered_models.append(clean_tok(t.children[0]).value)
        branches = t.children[2:]
        branches = list(group(branches, "PI"))

        a = []
        for branch in branches:
            a = a + self.traduce_branch(branch)

        branches = a

        b = self.current_bindings[len(self.current_bindings) - 1]

        #  resetto tutto quando faccio il return
        self.current_bindings = []
        self.current_branch = 0

        return Tree(t.data,
                    [
                        Token("ID", "def "), Token("ID", t.children[0].value), Token("ID", "(x)"), Token("COLON", ":")
                    ] +
                    self.add_tab_top_level(branches) +
                    [
                        Token("ID", "return "), Token("ID", b), Token("WS", "\n\n")
                    ]
                    )

    def traduce_branch(self, branch: list) -> list:
        # branch contiene una e perciò la facciamo uscire
        a = []
        for i in branch:
            self.current_branch += 1
            self.current_bindings.append(alphabet[self.current_branch - 1])
            a.append(self.traduce_layers(branch, "first"))
        return a

    # All' inizio t è una lista ma tutte le successive call sono su trees
    def traduce_layers(self, t: list, opt=""):
        # (layer + ( layer + layer ))

        if isinstance(t, list):
            t = t[0]

        if match(t.children, [1], ["PLUS"]) and len(t.children) == 3:
            if opt == "first":
                return Tree(t.data, [Tree(t.children[0].data, [self.traduce_layers(t.children[0], "first")]),
                                     Tree(t.children[2].data, [self.traduce_layers(t.children[2])])])
            else:
                return Tree(t.data, [Tree(t.children[0].data, [self.traduce_layers(t.children[0])]),
                                     Tree(t.children[0].data, [self.traduce_layers(t.children[2])])])

        if match(t.children, [0], ["ID"]) and len(t.children) > 1 and not match(t.children, [], ["PLUS"]):
            if clean_tok(t.children[0]).value == "assign":
                return Tree(t.data, [Token("ID", alphabet[self.current_branch - 1]), Token("EQ", "="), t.children[0],
                                     Token("LP", "(")] + map(self.transform, t.children[1:], "CO", ",") + [
                                Token("RP", ")"),
                                Token("WS", "\n\t")])

            if opt == "first":
                return Tree(t.data, [Token("ID", alphabet[self.current_branch - 1]), Token("EQ", "="), t.children[0],
                                     Token("LP", "(")] + map(self.transform, t.children[1:], "CO", ",") + [
                                Token("RP", ")"), Token("LP", "("), Token("ID", "x"), Token("RP", ")"),
                                Token("WS", "\n\t")])
            else:
                return Tree(t.data,
                            [
                                Token("ID", alphabet[self.current_branch - 1]),
                                Token("EQ", "="), t.children[0],
                                Token("LP", "(")] +
                            map(self.transform, t.children[1:], "CO", ",") +
                            [
                                Token("RP", ")"),
                                Token("LP", "("),
                                Token("ID", alphabet[self.current_branch - 1]),
                                Token("RP", ")"),
                                Token("WS", "\n\t")
                            ])

        if match(t.children, [0], ["ID"]) and match(t.children, [1], ["AR"]) and len(t.children) == 2:
            # preparati per dare 2 bindings
            pass

        if match(t.children, [0], ["ID"]) and match(t.children, [1], ["AR"]) and len(t.children) == 4:
            # concatena 2 concatenazioni che sono state bindate
            pass

        if match(t.children, [0], ["ID"]) and len(t.children) == 1:
            a = str(self.current_bindings[:len(self.current_bindings) - 1]).replace("'", "").replace("x,", "")
            self.current_bindings = ["x"]

            return Tree(t.data,
                        [
                            Token("ID", "x"),
                            Token("EQ", "="), t.children[0],
                            Token("LP", "("),
                            Token("RP", ")"),
                            Token("LP", "("),
                            Token("ID", a),
                            Token("RP", ")"),
                            Token("WS", "\n\t")
                        ])

        return Tree(t.data, [self.traduce_layers(t.children, opt)])
