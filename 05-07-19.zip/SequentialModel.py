from lark import Tree, Token

from mll.utils import clean_tok, apply, group, alphabet, match, map


class SequentialModel:

    def __init__(self):
        pass

    ###################################################################
    #                      SEQUENTIAL MODEL                           #
    ###################################################################

    def traduce_sequential(self, t: Tree):

        t.children[2:] = self.put_macros(t.children[2:])
        t = apply(t, lambda x: x, clean_tok)
        apply(t, lambda x: x, self.select_imported_libraries)
        self.models[clean_tok(t.children[0]).value] = 0
        self.select_imported_libraries(Token("ID", "Sequential"))
        t = apply(t, lambda x: x, self.solve_parmac)

        return Tree(t.data,
                    [Token("ID", "models"), Token("LSP", "["), Token("SQ", "'"), clean_tok(t.children[0]),
                     Token("SQ", "'"), Token("LSP", "]"), Token("EQ", "="), Token("ID", "Sequential"), Token("LP", "("),
                     Token("LSP", "[")] +
                    apply(map(self.transform, t.children[2:], "CO", ","), lambda x: x,
                          lambda x: Token("CO", ",") if x.type == "PLUS" else x) +
                    [Token("RSP", "]"), Token("RP", ")"), Token("WS", "\n\n")])