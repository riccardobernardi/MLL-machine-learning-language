from lark import Tree, Token

from mll.utils import clean_tok, apply, group, alphabet, match, map


class Macro:

    def __init__(self,macros):
        self.macros=macros

    def traduce(self, t: Token):
        if clean_tok(t).value in self.macros.keys():
            s = clean_tok(t).value
            return self.macros[s]
        else:
            return t

    def add(self,new:Tree) -> []:
        self.macros[clean_tok(new.children[0])] = new.children[2:]

        for i in list(self.macros.values()):
            apply(i, lambda x:x, self.traduce)

        return self.macros