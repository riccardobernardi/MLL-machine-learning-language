from lark import Tree, Token

from mll.utils import clean_tok, apply, group, alphabet, match, map


class ForkedModel:

    def __init__(self):
        pass

    ###################################################################
    #                        SIMPLE MODEL                             #
    ###################################################################

    def traduce_simple_model(self, t: Tree):

        t.children[2:] = self.put_macros(t.children[2:])
        t = apply(t, lambda x: x, clean_tok)
        apply(t, lambda x: x, self.select_imported_libraries)
        self.models[clean_tok(t.children[0]).value] = 0
        t.children[2:] = apply(t.children[2:], lambda x: x, self.substitute_model)
        t = apply(t, lambda x: x, self.solve_parmac)
        self.ordered_models.append(clean_tok(t.children[0]).value)

        if len(t.children[2:][0].children) == 1:
            return Tree(t.data,
                        [Token("ID", "models"), Token("LSP", "["), Token("SQ", "'"), clean_tok(t.children[0]),
                         Token("SQ", "'"), Token("LSP", "]"), Token("EQ", "=")]
                        +
                        map(self.transform, t.children[2:], "CO", ",")
                        + [Token("LP", "("), Token("RP", ")"), Token("WS", "\n")])
        return Tree(t.data,
                    [Token("ID", "models"), Token("LSP", "["), Token("SQ", "'"), clean_tok(t.children[0]),
                     Token("SQ", "'"), Token("LSP", "]"), Token("EQ", "=")]
                    +
                    map(self.transform, t.children[2:], "CO", ",")
                    + [Token("WS", "\n\n")])