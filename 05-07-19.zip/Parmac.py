from lark import Tree, Token

from mll.utils import clean_tok, apply, group, alphabet, match, map, flatten


class Parmac:

    def __init__(self, parmacs, macros):
        self.added_keys = []
        self.parmacs = parmacs

    def traduce(self, t: Token):
        if clean_tok(t).value in self.parmacs.keys():
            s = clean_tok(t).value
            return self.parmacs[s]
        else:
            return t

    def __translate_parmac(self, t: Tree):
        id = t.children[0].value
        a = t.children[2:]
        a = flatten(group(a, "OR"))

        for i in a:
            self.parmacs[clean_tok(i).value] = Token("ID", id + "=" + "'" + i.value + "'")

    def add(self, new: Tree) -> []:
        self.__translate_parmac(new)

        return self.parmacs